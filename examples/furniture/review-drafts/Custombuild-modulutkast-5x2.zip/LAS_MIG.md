# Modulutkast för granskning – 5 × 2 stommar

Detta är ett beräknat alternativ till kundfilens långa odelade delar.
Indelningen är ett exempel, inte ett valt kundutförande eller en materialorder.

- Stomvolym: 4340 × 2540 × 280 mm.
- Fem kolumner och två rader, 0 mm mellanrum.
- Tio separata stommar: 868 × 1270 × 280 mm per stomme.
- Två hyllplan per stomme, inga invändiga avdelare.
- Rad 1 är nederst; kolumn 1 längst till vänster.
- Beräknad sammanlagd egenvikt: 241,15 kg, utifrån källans screeningmaterial.
- Källans last på 200 N per hel hyllrad bevaras: 40 N per modulkolumn.
  Totalt 800 N över alla hyllplan. Detta är fortfarande källans standardlast,
  inte en bekräftad verklig boklast.

## Öppna arbetsfilerna

Packa upp ZIP-filen. Välj en JSON-fil i `moduler/` via **Läs arbetsfil (JSON)**
i möbelstudion. Spara den som ett nytt projekt för fortsatt redigering.
`modulplan.json` innehåller hela planen, källarbetsfilen och varje moduls
placering, beräknade delar och granskningskrav. Den är en planfil och ska inte
importeras som en enskild möbelarbetsfil.

## Kräver fortsatt konstruktion och verifiering

De ursprungliga installationsmåtten, okända montageutrymmena och listens olösta
funktion följer med varje arbetsfil. De behöver en granskad lösning för den nya
modulgruppen. Materialbatch, råformat och verklig maskin är inte valda.
Källfilens materialprofiler och 18/6 mm tjocklekar är planeringsvärden.

Separata stommar ändrar utseende, invändig volym, hyllplaceringar och vikt.
Förband och hålbilder mellan moduler, väggförankring, underlag och lastväg från
övre moduler är inte modellerade eller kvalificerade. Hyllscreeningen inkluderar
inte staplingslast. Dessa arbetsfiler ger inget tillverkningsgodkännande.

Ingen fysisk fräsning eller mätning ingår i detta underlag. Fastställ
konstruktion och provkrav tillsammans med verkstaden före fogprov och helmöbel.

## Spårbarhet

Generator: Custombuild commit 524c6d22eab5f1c02a80fd0dc831a195d306e9a0.
Källa: examples/furniture/bookcase-4340x2540x280.json på samma commit.
Alla filer i paketet kontrolleras mot `checksums.json`.
